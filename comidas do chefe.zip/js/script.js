    function mostrarSection(elemento) {
      const textoPrato = elemento.textContent.trim();
      const sections = document.querySelectorAll('#containe section');

      // Oculta todas as sections
      sections.forEach(section => {
        section.style.display = 'none';
      });

      // Mostra a section correspondente ao prato selecionado
      const sectionCorrespondente = document.getElementById(textoPrato);
      if (sectionCorrespondente) {
        sectionCorrespondente.style.display = 'block';
      }
    }